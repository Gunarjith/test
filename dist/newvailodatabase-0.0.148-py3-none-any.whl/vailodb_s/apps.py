from django.apps import AppConfig


class VailodbSConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vailodb_s'
